protocol = 1;
publishedid = 940368971;
name = "ARMA3 CUP Enhancement";
timestamp = 5248361188553456199;
